create
    definer = azure_superuser@localhost procedure az_ps_truncate_all_tables(IN in_verbose tinyint(1))
BEGIN    CALL sys.ps_truncate_all_tables(in_verbose); END;

